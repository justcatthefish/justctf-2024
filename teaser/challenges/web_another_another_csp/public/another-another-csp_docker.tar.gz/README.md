### Another Another CSP
To run locally:

1. Run
```sh
docker build -t another-another-csp . && docker run -d --rm -p "0.0.0.0:9090:80" another-another-csp
```
2. The app should be running on http://localhost:9090
#!/bin/sh

/usr/bin/supervisord -c /etc/supervisord.conf

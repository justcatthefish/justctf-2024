# Setup

```
docker compose up
```

[http://localhost:80](http://localhost:80)

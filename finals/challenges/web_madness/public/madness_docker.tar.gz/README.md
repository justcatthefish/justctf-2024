```sh
docker compose build
docker compose up
```

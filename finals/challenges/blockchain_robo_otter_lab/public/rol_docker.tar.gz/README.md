# addresses
pay attention to the module address returned by the server in `[SERVER] Challenge modules published at: 0x...` message. you have to copy-paste this address to:
- `framework-solve/dependency/Move.toml`
- `framework-solve/solve/Move.toml`

```toml
[addresses]
# TODO: update this address
challenge = "0x..."
```

# solve parameters list
you must manually define the list of arguments passed to the `solution::solve` function in the `framework-solve/solve/sources/solve.move` file.

1. to do this, first define the parameters list of the `solve()` function, the `&mut TxContext` parameter will be added automatically if you leave it on the parameters list
```move
public fun solve(
    /* TODO: other params */
    _ctx            : &mut TxContext
) {
    /*
     * TODO: put your code here
     */
}
```

2. then you need to manually define which objects to pass to the function. this is done by defining a `PARAMS_LIST` value in `framework-solve/src/main.rs`.
```rust
/// TODO: the list of `(x, y)` for `FakeID(x, y)` of objects that will be passed to the `solution::solve` function
const PARAMS_LIST: [(u8, u8); 0] = [
    /*
     * TODO: write list of params below
     * (5, 2),
     * (6, 8),
     */
];
```

3. to make determining the correct object IDs easier, I've added code that dumps existing objects in the server's implementation. you can get the list of objects with their IDs from the `framework-solve/objects_dump.txt` file or from the server's logs.
```
---
object(1, 0)
Owner: Shared( 2 )
Version: 2
Contents: challenge::robo_otter_lab::HydroTestTank {
    id: sui::object::UID {
        id: sui::object::ID {
            bytes: fake(1,0),
        },
    },
    required_efficiency: 10u8,
}
```
for example, if you want to pass a `HydroTestTank` object, either by value or by reference, all you have to do is add `(1, 0)` to the `PARAMS_LIST`:
```move
public fun solve(
    hydro_test_tank : &HydroTestTank,
    _ctx            : &mut TxContext
) {
    do_something_with(hydro_test_tank);
}
```
```rust
const PARAMS_LIST: [(u8, u8); 1] = [
    (1, 0),
];
```

#!/usr/bin/env bash

docker build -t re_quirk3 .
docker run --rm -it re_quirk3

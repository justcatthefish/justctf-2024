# !IMPORTANT!
We provide file of Windows OS as virtual machine using Docker.  
But this virtual machine works only when run on **Linux x86_64** with /dev/kvm enabled.
(it will not work on WindowsOS or macOS, but **maybe** you can use nested virtualization to run it inside Linux virtual machine)

## Differences between your local virtual machine and remote server
- network in remote serwer is disabled
- Windows restarts for each connection to the remote serwer, only note.exe restarts on your local virtual machine.
- You can connect via RDP to local virtual machine and get into graphical interface (and attach WinDbg).

## flag path
- `C:\chall\flag.txt`

## What is preinstalled inside local and remote VM:
- Windows 11 Pro (23H2) (22631.2861)
- note.exe challenge binary, own socat
- WinDbg
- RDP server

## How to run local windows VM:
```
# You need 14GB+ of free space, file is splitted to smaller files - 1GB each
# To get challenge files you can download them from links below or you can ask CTF organizers for USB storage with the challenge.
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_aa
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ab
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ac
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ad
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ae
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_af
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ag
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ah
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ai
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_aj
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_ak
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_al
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_am
wget https://s3.cdn.justctf.team/win-a795880f-7ea7-4d56-abfc-c1fdbb10e3c1/windows_vm_sparse.tar_an

# combine pieces into one file
cat windows_vm_sparse.tar_* > windows_vm_sparse.tar

# verify checksum
sha256sum windows_vm_sparse.tar

# untar sparse image
tar -xvSf windows_vm_sparse.tar

# run it
docker run -it --rm \
    -v "$PWD"/storage:/storage \
    -p 127.0.0.1:1337:1337 \
    -p 127.0.0.1:8006:8006 \
    -p 127.0.0.1:3389:3389/tcp \
    -p 127.0.0.1:3389:3389/udp \
    --device=/dev/kvm \
    --cap-add NET_ADMIN \
    --stop-timeout 120 \
    dockurr/windows@sha256:9490bcb2463c666a3c0b8497f97a9ab28186e67ff63614e510ecfcab96889a98
```

## How to connect into Windows graphical interface:
- Our recommended way is to use freerdp eg. using command: `xfreerdp /v:127.0.0.1:3389 /u:Docker /size:2500x1400` or use other screen size parameters. Password is empty
- http://127.0.0.1:8006 in browser should also work, but freerdp works much better. 

## How to connect to stdin/stdout of note.exe:
- `nc 127.0.0.1 1337`

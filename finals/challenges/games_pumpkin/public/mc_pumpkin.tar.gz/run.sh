#!/usr/bin/env bash

read -p 'By running this you agree to the Minecraft EULA. Press Enter to confirm'
echo 'eula=true' > eula.txt
docker compose up -d

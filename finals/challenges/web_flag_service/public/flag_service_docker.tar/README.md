To run the challenge locally just enter the `src` directory and run:

```sh
docker compose up --build
```

The app should be listening at `http://localhost`. You can change the local port (80) in `docker-compose.yaml`.